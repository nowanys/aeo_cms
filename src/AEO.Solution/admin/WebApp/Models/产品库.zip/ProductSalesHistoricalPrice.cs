﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Repository.Pattern.Ef6;

namespace WebApp.Models
{
  //产品历史价格(销售)
  public partial class ProductSalesHistoricalPrice : Entity
  {
    [Key]
    public int Id { get; set; }
    [Display(Name = "产品名称", Description = "产品名称")]
    [MaxLength(80)]
    public string ProductName{ get; set; }
    [Display(Name = "客户名称", Description = "客户名称")]
    [MaxLength(80)]
    public string CustomerName { get; set; }
    [Display(Name = "客户货号", Description = "客户货号")]
    [MaxLength(80)]
    public string CustomerProductNo { get; set; }

    [Display(Name = "日期", Description = "日期")]
    [DefaultValue("now")]
    public DateTime QuoteDate { get; set; }
    [Display(Name = "国家地区", Description = "国家地区")]
    [MaxLength(20)]
    public string Country { get; set; }

    [Display(Name = "币种", Description = "币种")]
    [MaxLength(10)]
    [DefaultValue("CNY")]
    public string CUR { get; set; }
  }
}