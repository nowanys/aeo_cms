﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Repository.Pattern.Ef6;

namespace WebApp.Models
{
  //产品串料信息
  public partial class ProductRef:Entity
  {
    [Key]
    public int Id { get; set; }
    [Display(Name = "产品编号", Description = "产品编号(自动生成,可手工修改)")]
    [MaxLength(50)]
    public string ProductNo { get; set; }
    [Display(Name = "中文品名", Description = "中文品名")]
    [MaxLength(200)]
    public string ProductName { get; set; }
    [Display(Name = "英文品名", Description = "英文品名")]
    [MaxLength(200)]
    public string ProductEName { get; set; }
    [Display(Name = "客户类型", Description = "客户类型")]
    [MaxLength(50)]
    public string CustomerType { get; set; }
    [Display(Name = "客户代码", Description = "客户代码(保存时系统自动分配也可以手工选择)")]
    [MaxLength(20)]

    public string CustomerCode { get; set; }
    [Display(Name = "客户名称", Description = "客户名称")]
    [MaxLength(80)]
    [Required]
    public string CustomerName { get; set; }
  
    [Display(Name = "客户货号", Description = "客户货号")]
    [MaxLength(50)]
    public string CustomerProductNo { get; set; }
    [Display(Name = "产品描述", Description = "产品描述")]
    [MaxLength(200)]
    public string Desc { get; set; }

  }
}